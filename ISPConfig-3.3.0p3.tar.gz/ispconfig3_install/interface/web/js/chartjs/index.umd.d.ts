/**
 * @namespace Chart
 */
import Chart from './core/core.controller.js';
export default Chart;
