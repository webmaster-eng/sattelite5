<?php
$db_user = '{mysql_server_ispconfig_user}';
$db_pass = '{mysql_server_ispconfig_password}';
$db_name = '{mysql_server_database}';
$db_host = '{mysql_server_ip}';
$isp_server_id = '{server_id}';