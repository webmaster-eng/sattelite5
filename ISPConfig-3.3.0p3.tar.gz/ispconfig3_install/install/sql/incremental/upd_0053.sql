ALTER TABLE `web_domain` ADD `last_quota_notification` DATE NULL DEFAULT NULL;
ALTER TABLE `mail_user` ADD `last_quota_notification` DATE NULL DEFAULT NULL;
