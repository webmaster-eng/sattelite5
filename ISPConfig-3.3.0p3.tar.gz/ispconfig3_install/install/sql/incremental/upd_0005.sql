ALTER TABLE client ADD COLUMN company_id varchar(30);

